<?php

namespace Database\Seeders;

use App\Models\Product;
use App\Models\User;
use App\Models\Wherehouse;
use App\Models\WherehouseProduct;
// use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        // User::factory(10)->create();

        User::factory()->create([
            'name' => 'haruto',
            'email' => 'haruto@example.com',
            'password' => "haruto"
        ]);
        Wherehouse::factory()->create([
            'code' => 'AV 6',
            'name' => 'Audio Visual 6'
        ]);
        Product::factory()->create([
            'code' => '11112',
            'name' => 'Monitor Asus',
            'price' => 1650000
        ]);
        WherehouseProduct::factory()->create([
            'Wherehouse_id'=> 1,
            'user_id'=> 1,
            'status'=> 'success',
            'register'=> '2024-10-24'
        ]);

        $log_product = [
            [
                'Wherehouse_product_id'=> 1,
                'product_id' => 1,
                'amount'=> 30,
                'type'=> 'in',
                'status' => 'good'
            ],
            [
                'Wherehouse_product_id'=> 1,
                'product_id' => 1,
                'amount'=> 20,
                'type'=> 'in',
                'status' => 'bad'
            ]
        ];

        DB::table('log_products')->insert($log_product);

    }
}
