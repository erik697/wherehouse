
<?php /**PATH C:\laragon\www\wherehouse\resources\views/product/show.blade.php ENDPATH**/ ?>