    

    <?php $__env->startSection('content'); ?>
         <!-- Begin Page Content -->
         <div class="container-fluid">

            <!-- Page Heading -->
            <div class="h3 mb-2 text-gray-800">
                <form action="<?php echo e(route('manageWherehouse.index')); ?>" class="row ">
                <select class="custom-select col-md-11" name="id">
                    <option selected disabled>-- Wherehouse --</option>
                    <?php $__currentLoopData = $wherehouses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($item->id); ?>" <?php if($id==$item->id): ?> selected <?php endif; ?>><?php echo e($item->code); ?> | <?php echo e($item->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                  <button type="submit" class="btn btn-primary btn-icon-split mx-2">
                    <span class="icon text-white-50">
                        <i class="fas fa-search"></i>
                    </span>
                    <span class="text">Search</span>
                </button>

                </form>
            </div>

            <?php if(Session::has('message')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <strong>Success</strong> <?php echo e(Session::get('message')); ?>

                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
              </div>
            <?php endif; ?>

            <!-- DataTales Example -->
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">List Product</h6>
                </div>
                <div class="card-body">
                
                    <a href="<?php echo e(route('manageWherehouse.createNewProduct', ['wherehouse_id'=>$id])); ?>" class="btn btn-primary btn-icon-split mb-2">
                        <span class="icon text-white-50">
                            <i class="fas fa-plus"></i>
                        </span>
                        <span class="text">Add</span>
                    </a>
                
                    <div class="table-responsive">
                        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                            <thead>
                                <tr>
                                    <th>Code</th>
                                    <th>Name</th>
                                    <th>Amount</th>
                                    <th>Good</th>
                                    <th>Bad</th>
                                    <th>Amount</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tfoot>
                                <tr>
                                    <th>Code</th>
                                    <th>Name</th>
                                    <th>Amount</th>
                                    <th>Good</th>
                                    <th>Bad</th>
                                    <th>Amount</th>
                                    <th>Action</th>
                                </tr>
                            </tfoot>
                            <tbody>
                                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($item->code); ?></td>
                                    <td><?php echo e($item->name); ?></td>
                                    <td><?php echo e($item->price); ?></td>
                                    <td><?php echo e($item->good); ?></td>
                                    <td><?php echo e($item->bad); ?></td>
                                    <td><?php echo e(rupiah($item->amount)); ?></td>
                                    <td>
                                        <a href="<?php echo e(route('manageWherehouse.listLogs', ['id'=>$item->id])); ?>" class="btn btn-warning mb-2">
                                            <span class="icon text-white-50">
                                                <i class="fas fa-pen"></i>
                                            </span>
                                        </a>
                                        
                                        
                                    </td>
                                </tr>        
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                               
                              
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

        </div>
        <!-- /.container-fluid -->
    <?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\wherehouse\resources\views/manageWherehouse/index.blade.php ENDPATH**/ ?>