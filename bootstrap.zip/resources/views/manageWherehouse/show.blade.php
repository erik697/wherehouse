{{--
    @extends('layouts.app')

    @section('content')
        product.show template
    @endsection
--}}
