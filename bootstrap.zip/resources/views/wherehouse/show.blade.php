{{--
    @extends('layouts.app')

    @section('content')
        wherehouse.show template
    @endsection
--}}
